# Vanshika Portfolio

Folder structure:

    vanshika-portfolio/
      index.html        -> page structure (Home, About, Projects, Skills, Contact)
      css/style.css     -> all design and animations
      js/script.js      -> all interactions (pages, chatbot, globe, marquees, form)
      images/
        vanshika.jpg    -> your photo (hero + About)
        chatbot-logo.png -> chatbot logo

## VS Code mein kaise chalayein
1. VS Code mein File > Open Folder karke `vanshika-portfolio` folder kholo.
2. Extensions mein "Live Server" install karo.
3. `index.html` par right click > "Open with Live Server".
(Live Server na ho to `index.html` ko seedha browser mein double-click karke bhi khol sakti ho.)

## Kya kahan badlein
- WhatsApp number / email: `index.html` mein `9671970922` aur `vanshikasharma032009@gmail.com` search karke badlo. `js/script.js` mein bhi yahi dono hain (chatbot ke liye).
- Photo badalni ho: `images/vanshika.jpg` ko usi naam se replace kar do.
- Project cards: `index.html` mein `<section class="page" id="projects">` ke andar.
- Skills ke percentage: `js/script.js` mein `var sk=[[...]]`.
- AI tools ki list: `js/script.js` mein `var tools=[...]`.
- Colors: `css/style.css` ke upar `:root{...}` mein.
- LinkedIn aur Instagram: `index.html` mein `linkedin.com` aur `instagram.com` ko apne profile links se badlo.

## Chatbot
Chat bubble ke AI jawab sirf Claude ke andar chalne wale link par aate hain.
VS Code ya apni hosting par built-in jawab chalte hain (projects, skills, contact ke baare mein).

## Online daalna
Poora folder Netlify, Vercel ya GitHub Pages par upload kar do (free).
